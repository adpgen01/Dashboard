# Education Dashboard

This is a Streamlit-based dashboard for education program data.

## How to Deploy on Streamlit Cloud

1. Create a GitHub repository (e.g., `education-dashboard`).
2. Upload the following files:
   - `dashboard.py`
   - `requirements.txt`
   - `Education_Program_Data_With_FakeRows.xlsx` (optional, for sample data)
3. Go to [Streamlit Cloud](https://streamlit.io/cloud).
4. Click **New App**, connect your GitHub repo, and select `dashboard.py` as the entry point.
5. Deploy and share the link!

## Run Locally

```bash
pip install -r requirements.txt
streamlit run dashboard.py
```

## Build Offline Executable (Windows)

If you want to distribute without requiring Python:

```bash
pip install pyinstaller
pyinstaller --onefile --noconsole dashboard.py
```

Your executable will be in the `dist` folder as `dashboard.exe`.
